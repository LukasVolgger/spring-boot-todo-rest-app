package at.lukas.volgger.todorestapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TodoRestAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
