package at.lukas.volgger.todorestapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TodoRestAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(TodoRestAppApplication.class, args);
	}

}
